package androidx.core.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    public ViewPropertyAnimatorListenerAdapter() {
    }

    public void onAnimationStart(View view) {
    }

    public void onAnimationEnd(View view) {
    }

    public void onAnimationCancel(View view) {
    }
}
